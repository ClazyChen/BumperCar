rotate_decrease_alpha = 50 
forward_decrease_constant = 0.3 
collision_constant = 0.7 
epsilon = 1e-4
collide_epsilon = 1.5 
forward_increase_constant = 300 
rotate_increase_alpha = 150 

width = 800
height = 600
